def main():
    x = input()

    if x.endswith(":)"):
        x = x.replace(":)", "🙂")
        print(x)

    elif x.endswith(":("):
        x = x.replace(":(", "🙁")
        print(x)

main()
