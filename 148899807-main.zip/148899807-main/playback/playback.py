def playback():
    x = input().replace(" ", "...")
    print(x)
playback()
