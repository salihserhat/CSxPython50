def indoor():
    x = input()
    x = x.casefold()
    print(x)

indoor()
